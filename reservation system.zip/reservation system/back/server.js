const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

app.use(bodyParser.json());
app.use(cors());

let vehicle = [
    {
        id: 1,
        name: 'NARENDAR',
        phone: '8508774247',
        vName: 'bike',
        count: '1',
        noDays: '2'
      },
      {
        id: 2,
        name: 'RAM',
        phone: '9994511882',
        vName: 'scooter',
        count: '1',
        noDays: '2'
      }
];

app.get("/view", (req, res) => {
    try {
        res.json({ vehicle });
    } catch (err) {
        res.status(500).json({ error: true, message: err.message });
    }
});

app.post("/create", (req, res) => {
    try {
        const { name, phone, vName, count, noDays } = req.body;
        if (!name || !phone || !vName || !count || !noDays) {
            return res.status(400).json({ error: true, message: "All fields are required" });
        
        }
        const id = vehicle.length > 0 ? vehicle[vehicle.length - 1].id + 1 : 1;
        const newBooking = {
            id: id,
            name: name,
            phone: phone,
            vName: vName,
            count: count,
            noDays: noDays
        };
        vehicle.push(newBooking);
        console.log(vehicle);
        res.json({ error: false, newBooking }); // Sending back the newly created booking
    } catch (err) {
        res.status(500).json({ error: true, message: err.message });
    }
});

app.put("/update/:id", (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const { name, phone, vName, count, noDays } = req.body;
        if (!name || !phone || !vName || !count || !noDays) {
            return res.status(400).json({ error: true, message: "All fields are required" });
        }
        const index = vehicle.findIndex(booking => booking.id === id);
        if (index !== -1) {
            vehicle[index] = {
                id: id,
                name: name,
                phone: phone,
                vName: vName,
                count: count,
                noDays: noDays
            };
            console.log(vehicle);
            res.json({ error: false });
        } else {
            res.status(404).json({ error: true, message: "Booking not found" });
        }
    } catch (err) {
        res.status(500).json({ error: true, message: err.message });
    }
});

app.delete("/delete/:id", (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const index = vehicle.findIndex(booking => booking.id === id);
        if (index !== -1) {
            vehicle.splice(index, 1);
            console.log(vehicle);
            res.json({ error: false });
        } else {
            res.status(404).json({ error: true, message: "Booking not found" });
        }
    } catch (err) {
        res.status(500).json({ error: true, message: err.message });
    }
});

const port = process.env.PORT || 5000;
app.listen(port, () => {
    console.log("Server is running on port:", port);
});
